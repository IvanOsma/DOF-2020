# Set up instructions

Run the following commands to install dependencies:

`pip install -r path/to/requirements.txt --user --upgrade pip`

You will see some errors/warnings but the notebook will execute correctly.
