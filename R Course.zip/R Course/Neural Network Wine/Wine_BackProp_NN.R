#load data
mydata <- read.csv("E:/R/wine.csv")
attach(mydata)

#Max-Min Normalization
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
  
}
maxmindf <- as.data.frame(lapply(mydata, normalize))

#Training and Test Data using normalized data
trainset <- maxmindf[1:142, ]
testset <- maxmindf[143:178, ]

#Neural Network
library(neuralnet)
nn <- neuralnet(Wine ~ Alcohol + Malic.acid + Ash + Acl + Mg + Phenols + Flavanoids + Nonflavanoid.phenols + Proanth + Color.int + Hue + OD + Proline, data=trainset, hidden=c(10,10,10), linear.output=FALSE, threshold=0.01)
nn$result.matrix
plot(nn)


#Test the resulting output
temp_test <- subset(testset, select = c("Alcohol", "Malic.acid", "Ash", "Acl", "Mg", "Phenols", "Flavanoids", "Nonflavanoid.phenols", "Proanth", "Color.int", "Hue", "OD", "Proline"))
head(temp_test)
nn.results <- compute(nn, temp_test)

#Accuracy check with Confusion Matrix
results <- data.frame(actual = testset$Wine, prediction = nn.results$net.result)
results
roundedresults<-sapply(results, round, digits=0)
roundedresultsdf=data.frame(roundedresults)
attach(roundedresultsdf)
table(actual,prediction)
