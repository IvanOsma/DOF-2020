#load data
mydata <- read.csv("E://CL1.csv")
attach(mydata) #Data del Todo el cluster con PWf
wellscl3 <- read.csv("E://WellsCL1Norm.csv")
attach(wellscl3) #Data todos pozos de cluster 3

#Funci�n de Normalizaci�n en base a M�ximos y M�nimos: Solo usar para dataset de entrenamiento de cluster incluyendo Pwf
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
  
}
maxmindf <- as.data.frame(lapply(mydata, normalize)) # Data Observada para entrenamiento con Pwf normalizada


#Training and Test Data using normalized data
trainset <- maxmindf[1:3526, ] # <- Viene de mydata normalizado con Pwf
#testset <- maxminwelldf # <- Viene de welldata normalizado

#Neural Network
library(neuralnet)
nn <- neuralnet(Pwf ~ THP + Qt_CD + Qw_CD + PPMCL, data=trainset, rep=0, hidden=c(4,2), linear.output=FALSE, threshold=0.01)
nn$result.matrix
plot(nn)

# RED ENTRENADA!

# COMIENZA LOOP DE PREDICC�ON
# Leer datos normalizados en base al dataset de entrenamiento

wellstart <- 1
wellend <- 645

wellnorm <- c(NA,NA,NA,NA,NA)#Variable para la normalizaci�n pozo a pozo
totalnorm <- c(NA,NA,NA,NA,NA)#Variable almacena normalizaci�n
totalwell <- c(NA,NA,NA,NA,NA)#Variable almacena datos todos los pozos sin normalizar
totalpredict <- c(NA)#Variable almacena todas las predicciones

#Ciclo-For de Predicci�n: Normalizaci�n y Evaluaci�n de la red neuronal para ciclos wellend

for(i in 1:wellend){
  currentwellset <- subset(wellscl3, Well==i)
  if(nrow(currentwellset)>0){
    wellnorm <- currentwellset
    totalwell <- rbind(totalwell, wellnorm) #ACUMULA / Almacena la selecci�n de datos de pozo sin normalizar
    temp_test <- subset(wellnorm, select = c("THP", "Qt_CD", "Qw_CD", "PPMCL"))
    nn.predict <- predict(nn,temp_test) #IO Predicci�n a partir de datos de prueba del pozo
    totalpredict <- rbind(totalpredict, nn.predict) #ACUMULA / Almacena todas las predicciones normalizadas
    cat('\n', 'Pozo # ', i,"/",wellend)
  }
}

write.csv(totalwell,"E://1TotalWellCl1.csv", row.names = FALSE)
write.csv(totalnorm,"E://2TotalNormCl1.csv", row.names = FALSE)
write.csv(totalpredict,"E://3TotalPredictCl1.csv", row.names = FALSE)


