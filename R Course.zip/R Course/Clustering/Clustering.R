#INSTALAR LIBRERIAS NECESARIAS
install.packages("magrittr") 
install.packages("dplyr")    
install.packages("data.table")
install.packages("factoextra")
install.packages("cluster.datasets")
install.packages("stringr")
install.packages("lubridate")
install.packages("nlme")
install.packages("readr")
install.packages("glm.deploy")
install.packages("anocva")
install.packages("gam")
install.packages("anova.Gam")
install.packages("ggpmisc")
install.packages("tidyverse")
install.packages("plotrix")
install.packages("corrgram")
install.packages("scales")
install.packages("rlang")
install.packages("remotes")
install.packages("stats")
#CARGAR LIBRERIAS 
library(flexclust) # ADDED IO
library(fpc) # ADDED IO
library(clustertend) # ADDED IO
library(ClusterR) # ADDED IO
library(clValid) # ADDED IO
library(clusterSim) # ADDED IO
library(ggplot2)
library(glm.deploy)
library(anocva)
library(mgcv)
require(mgcv)
library(mgcv)
library(ggpmisc)
library(tidyverse)  
library(readxl)
library(lubridate)
library(ggplot2)
library(plotrix)
library(dplyr)
library(magrittr)
library(corrgram)
library(corrplot)
library(magrittr) 
library(knitr)
library(data.table)
library(stringr)
library(cluster)
library(cluster.datasets)
library(tidyverse)
library(factoextra)


Bulk <- read_csv("E:/SPE 16 OCT - COLOMBIAN SECTION/R Course/Bulk.csv")
#Parsed with column specification:
cols(
  POZO = col_double(),
  BARRILES = col_double(),
  PRESION = col_double()
)
View(Bulk)
##str(Bulk)
#################################################################
df<-scale(Bulk) #IO: Dataframe del CSV
names(df)<-make.names(names(df))
res <- get_clust_tendency(df, 2, graph = TRUE)
#IO: get_clust_tendency(df=dataframe, 2=numero de puntos seleccionados por muestra, graph=TRUE/FALSE )
#IO: Hopkins statistic: If the value of Hopkins statistic is close to 1 (far above 0.5), then we can conclude that the dataset is significantly clusterable.
# Hopkins statistic = 0.9483386
res$hopkins_stat
res$plot
set.seed(123)
####################################################
# Compute the gap statistic
# IO: Identifies the optimum # of Clusters withina K.max range
gap_stat <- clusGap(df, FUN = kmeans, nstart = 25, 
                    K.max = 10, B = 500)

#IO: Plots gap analysis to see the optimum # of clusters from 10 (k.max=10) clusters.
fviz_gap_stat(gap_stat)

####################################################
#IO: Compute cluster Analysis K Meansc lustering with K=7
View(Bulk)
View(df)
set.seed(123)
#fviz_get_clust_tendency(tendencygap_stat) #VALIDAR! NO HAY REFERENCIAS DE ESTA FUNCION
#START KMEANS CLUSTERING
print("INICIO DE CLUSTERIZACI�N POR K-MEANS")
Sys.time()
km.res <- kmeans(df, 7, nstart =200)
print("FIN DE CLUSTERIZACI�N POR K-MEANS")
Sys.time()
#END K MEANS CLUSTERING

library("factoextra")
# Compute k-means
fviz_cluster(km.res, df) #IO: Visuals for Clustering Results



#IO: Silhouette measures (-1 to 1): 1=good cluster. -1=poor cluster
sil <- silhouette(km.res$cluster, dist(df))
fviz_silhouette(sil)

#ENHANCED CLUSTERING ANALYSIS
#res.km <- eclust(df, "kmeans")
#fviz_gap_stat(res.km$gap_stat) #Gap Satistic Plot
#res.hc <- eclust(df, "hclust") # compute hclust
#fviz_dend(res.hc, rect = TRUE) # dendrogam
#fviz_silhouette(res.hc) # silhouette plot


# Visualize clusters using factoextra
clusterfinal<-fviz_cluster(km.res, df)
# Visualize clusters using factoextra
fviz_cluster(km.res, df)
#Clustering validation
#The silhouette measures (SiSi) how similar an object ii is to the the other objects in its own cluster versus those in the neighbor cluster. SiSi values range from 1 to - 1: A value of SiSi close to 1 indicates that the object is well clustered.
#In the other words, the object ii is similar to the other objects in its group.
sil <- silhouette(km.res$cluster, dist(df))
rownames(sil) <- rownames(graf)
head(sil[, 1:3])
promediocluster<-fviz_silhouette(sil)
library(plyr)
data1<-rbind(km.res$cluster,Bulk)
data2<-cbind(km.res$cluster,Bulk)
View(data1)
View(promediocluster)
write.csv(data1,"E:/SPE 16 OCT - COLOMBIAN SECTION/R Course/data1.csv", row.names = FALSE)
write.csv(promediocluster,"E:/SPE 16 OCT - COLOMBIAN SECTION/R Course/promediocluster.csv", row.names = FALSE)
write.csv(km.res$cluster,"E:/SPE 16 OCT - COLOMBIAN SECTION/R Course/kmres.csv", row.names = FALSE)
write.csv(data2,"E:/SPE 16 OCT - COLOMBIAN SECTION/R Course/data2.csv", row.names = FALSE)
full_join()#Fuente
#https://rpubs.com/vsagar19/clustering
#https://gist.github.com/talegari/b514dbbc651c25e2075d88f31d48057b